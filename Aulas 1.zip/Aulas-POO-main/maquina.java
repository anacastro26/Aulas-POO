public class maquina {
    private String codigo;
    private int horimetro;
    private Float media;


    String getCodigo(){
        return this.codigo;
    }
    void setCodigo(String codigo){
        this.codigo = codigo;
    }


    int getHorimetro(){
        return this.horimetro;
    }
    Float getMedia(){
        return this.media;
    }

    void abastecer(float litros, int horimetro){
        this.media = (horimetro - this.horimetro) / litros;
        this.horimetro = horimetro;

    }


}
