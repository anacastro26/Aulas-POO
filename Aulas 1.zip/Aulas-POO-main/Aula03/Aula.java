
package Aula03;

public class Aula {

    public static void main(String[] args) {

        Casa dono = new Casa();

        dono.proprietario = "Angela";
        dono.endereco = "Av. das Tarumãs";
        dono.cidade = "Sinop";
        dono.cpf = "Bege";

        Empresa imobiliaria = new Empresa();
        
        imobiliaria.imovel = "empresa";
        imobiliaria.endereco = "Av.das Figueiras";
        imobiliaria.cidade = "Sinop-MT";
        imobiliaria.cor =  "Branca";
        imobiliaria.funcionario = "9";
        imobiliaria.cnpj =  " 00.000.000/0000-00";
        
        //dono.imobiliaria = proprietario;
        //.out.println(dono.proprietario.nomeProprietario);
        

        System.out.println("Imovel");
        System.out.println("Eu tenho uma: " + imobiliaria.imovel );
        System.out.println("Cidade: " + imobiliaria.cidade  );
        System.out.println("Avenida: " + imobiliaria.endereco);
        System.out.println("Cnpj:" +imobiliaria.cnpj );
        System.out.println("--------------------");
        System.out.println("Dono: " + dono.proprietario);
        System.out.println(" Cidade: " + dono.cidade );
        System.out.println(" Endereço " + dono.endereco  );
        System.out.println(" Cpf: " + dono.endereco  );




    }
}