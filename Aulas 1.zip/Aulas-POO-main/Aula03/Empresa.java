
public class Empresa {
    String imovel = "Empresa";
    String endereco = "Av. das figueiras";
    String cidade = "Sinop";
    String cor = "Branca";
    String funcionario = "9" ;
    String cnpj = " 00.000.000/0000-00";

}