
public class Casa {
    String proprietario = "Angela";
    String endereco = "Av. das Tarumãs";
    String cidade = "Sinop";
    String cpf = "000.000.000-00";
    Empresa imobiliaria = new Empresa();
}