public class Aula{
    public static void main(String[] args) {

        maquina maquinario = new maquina();

        maquinario.setCodigo("TR001");
        maquinario.abastecer(50, 10);

        System.out.println("A media da maquina" + maquinario.getCodigo() + " é " + maquinario.getMedia() + "H/LT");




        //Aluno academicos = new Aluno("Dani");

        //academicos.setaniversario(23);
        //academicos.aniversario ();
        //System.out.println(academicos.getIdade());
        //System.out.println(academicos.getNome());

        //academicos.setaniversario(22);
        //System.out.println(academicos.getIdade());
        //System.out.println(academicos.getNome());



    }
}
