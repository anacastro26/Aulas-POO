public public class ProgramaCarro {
    public static void main(String[] args){
        
        System.out.println("Olá");

        Carro uno = new Carro();

        uno.anoDeFabricacao = 2022;
        uno.cor = "Vermelho";
        uno.fabricante = "Fiat";
        uno.modelo = "Way";
    }

}class ProgramaCarro {
    
}
