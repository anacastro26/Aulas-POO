
public class Celular {
    String ano;
    String cor;
    String marca;
    int preco;

    Celular (String marca){
        this.marca = marca;
    }

    Celular (String marca, String cor){
        this.marca = marca;
        this.cor = cor;
    }

    Celular void meuCelular(){
        System.out.println( marca + "" );

    }
    void valor(){
        System.out.println( preco + "" );

    }

    void somar(int preco ){
        this.preco = this.preco + preco;

    }

    void meuTel(){
        System.out.println( marca + " do ano " + ano );

    }

    String meuFone(){ //fun
        String marcaCor = marca + " da cor " + cor;
        return marcaCor;
    }
}
