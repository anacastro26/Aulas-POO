public class Aula {
    public static void main(String[] args) {

        Celular mCelular = new Celular("Samsung","Preto");


        mCelular.ano = "2016";

        mCelular.preco = 1222;

        mCelular.meuFone();

       // mCelular.valor();
       //mCelular.somar(2);
      //  mCelular.valor();

        //System.out.println("" );

        //System.out.println("Eu tenho um: " + mCelular.marca );
        //System.out.println("Na cor: " + mCelular.cor  );
        //System.out.println("Do ano: " + mCelular.ano);

        //System.out.println("-------------------------------" );

        //String marcaCor = mCelular.meuFone();
        //System.out.println(marcaCor);
        //mCelular.meuCelular();
       // mCelular.meuTel();
    }
}