import java.util.Scanner;



public class Tarefacasa{
    public static void main(String[] args){



    //Tarefa
    // trazer um progrma em java e trazer se a juliana passou nota1 2 e nota 3 se ficou de exame faz a conta


 Scanner entrada = new Scanner(System.in);

        System.out.println("Digite seu Nota 1: ");
       float nota1 = entrada.nextFloat();
       System.out.println("Digite sua Nota 2:");
       float nota2 = entrada.nextFloat();
       System.out.println("Digite sua Nota 3 :");
       float nota3 = entrada.nextFloat();


       float media = (nota1 + nota2 + nota3) / 3;


       System.out.println("Sua média é : " + media);

        if (media >= 7) {
            System.out.println("Parabéns você está aprovado! Sua média é : " + media  );
        }else if (media >= 4.2 && media <= 6.9){ 
            float mediaexame = 10 - media;
            System.out.println("Você está de Exame! Falta: " + mediaexame + " para passar!" );  
        }else if (media < 4.5){   
         System.out.println("Você está reprovado! Sua média é : " + media  );
        }
         
      
      
      
       //System.out.println("Seu IMC é : " + imc);

      // if (imc < 18.5) {
       //     System.out.println("Você está abaixp do peso!");
       // }else if (imc >= 18.5 && imc <= 24.9){
       //     System.out.println("Você está no peso normal!");
       // }else if (imc >= 25 && imc <= 29.9){
       //     System.out.println("Você está acima do peso!");
       // }else if (imc >= 30 && imc <= 34.9){
       //     System.out.println("Você está com obesidade 1!");
        //}else if (imc >= 35 && imc <= 39.9){
       //     System.out.println("Você está com obesidade 2!");
      //  }else if (imc >= 40){
       //    System.out.println("Você está com obesidade Morbida!");
       // }





       // Scanner entrada = new Scanner(System.in);

       // System.out.println("Digite seu peso: ");
   //     float peso = entrada.nextFloat();
     //   System.out.println("Digite sua altura :");
  //      float altura = entrada.nextFloat();


//        float imc = peso / (altura * altura);

      //  System.out.println("Seu IMC é : " + imc);

        //if (imc < 18.5) {
          //  System.out.println("Você está abaixp do peso!");
        //}else if (imc >= 18.5 && imc <= 24.9){
         //   System.out.println("Você está no peso normal!");
       // }else if (imc >= 25 && imc <= 29.9){
          //  System.out.println("Você está acima do peso!");
       // }else if (imc >= 30 && imc <= 34.9){
         //   System.out.println("Você está com obesidade 1!");
      //  }else if (imc >= 35 && imc <= 39.9){
         //   System.out.println("Você está com obesidade 2!");
       // }else if (imc >= 40){
        //   System.out.println("Você está com obesidade Morbida!");
      //  }

 

//objeto
        //Scanner entrada = new Scanner(System.in);

       // System.out.println("Digite seu nome:");
       // String nome = entrada.nextLine();
       // System.out.println("O seu nome é:" + nome);





//ordem
       // int a = 1;
       // int b = 2;

       //  System.out.println("A soma de a + b é:" + (a + b));


//média de nota
       // int nota1 = 10;
       // int nota2 = 9;
       // int nota3 = 10;

      //  float notaFinal = (float) (nota1 + nota2 + nota3) / 3;

      //  int variavelFinal = ((nota1 + nota2 + nota3) / 3 );
      //  System.out.print((nota1 + nota2 + nota3) / 3 );

      //  System.out.println("A nota da Juliana é: " + variavelFinal );

//soma, divisao, subtracao, multiplicacao
        //int x = 10;
         //int y = 5;

         //System.out.println(x + y);
         //System.out.println(x - y);
         //System.out.println(x * y);
         //System.out.println(x / y);
       // +
       // -
       // /
       // *
    }
}