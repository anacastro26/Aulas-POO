public enum StatusAr {
    DESLIGADO,
    LIGADO
}
