public class Entidade {
    String nome = "SEM NOME";
    String documento;
    int pontosCarteira;
    String logradouro;
    String cidade;    
}
