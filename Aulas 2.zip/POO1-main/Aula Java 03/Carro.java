public class Carro {
    String modelo;
    String cor;
    int anoFabricacao;
    String motor;
    String fabricante;
    String chassi;
    Entidade proprietario = new Entidade();
}