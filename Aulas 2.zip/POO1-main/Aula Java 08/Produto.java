public abstract class Produto {

    String descricao;

    public abstract void imprimirEtiqueta();
    
}
