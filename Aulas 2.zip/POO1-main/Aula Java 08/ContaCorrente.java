public class ContaCorrente extends Conta{

    private double limite;

    public void setLimite(double limite){
        this.limite = limite;
    }

    public double getLimite(){
        return this.limite;
    }
    
}
